<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="map" tilewidth="32" tileheight="32" tilecount="357" columns="17">
 <image source="map.jpeg" width="544" height="672"/>
</tileset>
